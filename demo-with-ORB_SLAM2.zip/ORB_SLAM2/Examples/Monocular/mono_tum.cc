/**
* This file is part of ORB-SLAM2.
*
* Copyright (C) 2014-2016 Raúl Mur-Artal <raulmur at unizar dot es> (University of Zaragoza)
* For more information see <https://github.com/raulmur/ORB_SLAM2>
*
* ORB-SLAM2 is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* ORB-SLAM2 is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with ORB-SLAM2. If not, see <http://www.gnu.org/licenses/>.
*/


#include<iostream>
#include<algorithm>
#include<fstream>
#include<chrono>

#include<opencv2/core/core.hpp>

#include<System.h>
#include <boost/filesystem.hpp>///yqh

using namespace std;

void LoadImages(const string &strFile, vector<string> &vstrImageFilenames,
                vector<double> &vTimestamps);
/// ./Examples/Monocular/mono_tum Vocabulary/ORBvoc.txt Examples/Monocular/TUM1.yaml /media/nubot22/QQ320G/[data-sets]/vision.in.tum.de_data_datasets/Handheld\ SLAM/rgbd_dataset_freiburg1_desk
int main(int argc, char **argv)
{
    if(argc != 5)///yqh add the 4th parameter of file_save_dir
    {
        cerr << endl << "Usage: ./mono_tum path_to_vocabulary path_to_settings path_to_sequence" << endl;
        return 1;
    }

    // Retrieve paths to images
    vector<string> vstrImageFilenames;
    vector<double> vTimestamps;
    string strFile = string(argv[3])+"/rgb.txt";
    LoadImages(strFile, vstrImageFilenames, vTimestamps);

    int nImages = vstrImageFilenames.size();

    std::string file_save_dir =  argv[4];
    if( !boost::filesystem::is_directory(file_save_dir) )
    {
        if(boost::filesystem::create_directory(file_save_dir))
            std::cout << "\033[43;31mcreat directory: " << file_save_dir << "\033[m" << std::endl;
        else
        {
            std::cout << "\033[43;31mFailed to creat directory: " << file_save_dir << "\033[m\007" << std::endl;
            return 1;
        }
    }
    else
        std::cout << "\033[43;31mFiles will be saved in directory: " << file_save_dir << "\033[m" << std::endl;

    // Create SLAM system. It initializes all system threads and gets ready to process frames.
    ORB_SLAM2::System SLAM(argv[1],argv[2],ORB_SLAM2::System::MONOCULAR,true,file_save_dir+"yqh");//yqh? 不加点东西运行会报错
    SLAM.mpTracker->static_kf_interval = 30;
    boost::filesystem::create_directory(file_save_dir+"yqh"+"keyframes/");
    std::ofstream trajectory_file, covar_pose_file, covar_covis_file;
    trajectory_file.open( (file_save_dir+"pose.txt").c_str());///yqh
    trajectory_file << "#timestamp tx ty tz qx qy qz qw" << std::endl;///yqh
    trajectory_file << std::fixed;
    covar_pose_file.open((file_save_dir+"covar_pose.txt").c_str());///yqh
    covar_pose_file << "#c11 c12 c13 c14 c15 c16 c22 c23 c24 c25 c26 c33 c34 c35 c36 c44 c45 c46 c55 c56 c66" << std::endl;///yqh 对称矩阵
    covar_covis_file.open((file_save_dir+"covar_covis.txt").c_str());///yqh
    covar_covis_file << "#c11 c12 c13 c14 c15 c16 c22 c23 c24 c25 c26 c33 c34 c35 c36 c44 c45 c46 c55 c56 c66" << std::endl;///yqh 对称矩阵
    Eigen::Matrix3f Rotate_cam2groundtruth;//yqh Warning!!! x=z y=-x z=-y
    Rotate_cam2groundtruth << 1,0,0,  0,1,0,  0,0,1;

    // Vector for tracking time statistics
    vector<float> vTimesTrack;
    vTimesTrack.resize(nImages);

    cout << endl << "-------" << endl;
    cout << "Start processing sequence ..." << endl;
    cout << "Images in the sequence: " << nImages << endl << endl;

    // Main loop
    cv::Mat im;
    for(int ni=0; ni<nImages; ni++)
    {
        // Read image from file
        im = cv::imread(string(argv[3])+"/"+vstrImageFilenames[ni],CV_LOAD_IMAGE_UNCHANGED);
        double tframe = vTimestamps[ni];

        if(im.empty())
        {
            cerr << endl << "Failed to load image at: "
                 << string(argv[3]) << "/" << vstrImageFilenames[ni] << endl;
            return 1;
        }

#ifdef COMPILEDWITHC11
        std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();
#else
        std::chrono::monotonic_clock::time_point t1 = std::chrono::monotonic_clock::now();
#endif

        // Pass the image to the SLAM system
        cv::Mat Tcw_yqh = SLAM.TrackMonocular(im,tframe);
        if( !Tcw_yqh.empty() )
        {
            cv::Mat Twc_yqh = Tcw_yqh.inv();
            Eigen::MatrixXf Twc_eigen = Eigen::Map<Eigen::MatrixXf>( (float*)Twc_yqh.data, 4, 4 ).transpose();//eig矩阵默认按列存储 (4,4,CV_32F)
            Eigen::Vector3f position = Twc_eigen.topRightCorner<3,1>();
            position = Rotate_cam2groundtruth*position;
            Eigen::Matrix3f R_eigen = Rotate_cam2groundtruth*Twc_eigen.topLeftCorner<3,3>();
            Eigen::Quaternionf orientation( R_eigen );

            trajectory_file << std::setprecision(4) << tframe << " " << position(0) << " " << position(1) << " " << position(2)
                      << " " << orientation.x() << " " << orientation.y() << " " << orientation.z() << " " << orientation.w() << std::endl;

            Eigen::Matrix<double, 6, 6> covariance_pose = SLAM.mpTracker->mCurrentFrame.sigma2_pose_;
            Eigen::Matrix<double, 6, 6> covariance_covis = SLAM.mpLocalMapper->sigma2_covisible;
            Eigen::Matrix6d rotate6d;
            rotate6d.setZero();
            rotate6d.topLeftCorner<3,3>() = Rotate_cam2groundtruth.cast<double>();
            rotate6d.bottomRightCorner<3,3>() = Rotate_cam2groundtruth.cast<double>();
            covariance_pose  = rotate6d * covariance_pose  * rotate6d.transpose();
            covariance_covis = rotate6d * covariance_covis * rotate6d.transpose();
            covar_pose_file<<covariance_pose(0,0)<<" "<<covariance_pose(0,1)<<" "<<covariance_pose(0,2)<<" "<<covariance_pose(0,3)<<" "<<covariance_pose(0,4)<<" "<<covariance_pose(0,5)<<" "
                           <<covariance_pose(1,1)<<" "<<covariance_pose(1,2)<<" "<<covariance_pose(1,3)<<" "<<covariance_pose(1,4)<<" "<<covariance_pose(1,5)<<" "
                           <<covariance_pose(2,2)<<" "<<covariance_pose(2,3)<<" "<<covariance_pose(2,4)<<" "<<covariance_pose(2,5)<<" "
                           <<covariance_pose(3,3)<<" "<<covariance_pose(3,4)<<" "<<covariance_pose(3,5)<<" "
                           <<covariance_pose(4,4)<<" "<<covariance_pose(4,5)<<" "
                           <<covariance_pose(5,5)<<" "<< std::endl;
            covar_covis_file<<covariance_covis(0,0)<<" "<<covariance_covis(0,1)<<" "<<covariance_covis(0,2)<<" "<<covariance_covis(0,3)<<" "<<covariance_covis(0,4)<<" "<<covariance_covis(0,5)<<" "
                            <<covariance_covis(1,1)<<" "<<covariance_covis(1,2)<<" "<<covariance_covis(1,3)<<" "<<covariance_covis(1,4)<<" "<<covariance_covis(1,5)<<" "
                            <<covariance_covis(2,2)<<" "<<covariance_covis(2,3)<<" "<<covariance_covis(2,4)<<" "<<covariance_covis(2,5)<<" "
                            <<covariance_covis(3,3)<<" "<<covariance_covis(3,4)<<" "<<covariance_covis(3,5)<<" "
                            <<covariance_covis(4,4)<<" "<<covariance_covis(4,5)<<" "
                            <<covariance_covis(5,5)<<" "<< std::endl;
        }

#ifdef COMPILEDWITHC11
        std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
#else
        std::chrono::monotonic_clock::time_point t2 = std::chrono::monotonic_clock::now();
#endif

        double ttrack= std::chrono::duration_cast<std::chrono::duration<double> >(t2 - t1).count();

        vTimesTrack[ni]=ttrack;

        // Wait to load the next frame
        double T=0;
        if(ni<nImages-1)
            T = vTimestamps[ni+1]-tframe;
        else if(ni>0)
            T = tframe-vTimestamps[ni-1];

        if(ttrack<T)
            usleep((T-ttrack)*1e6);
    }

    // Stop all threads
    SLAM.Shutdown();

    // Tracking time statistics
    sort(vTimesTrack.begin(),vTimesTrack.end());
    float totaltime = 0;
    for(int ni=0; ni<nImages; ni++)
    {
        totaltime+=vTimesTrack[ni];
    }
    cout << "-------" << endl << endl;
    cout << "median tracking time: " << vTimesTrack[nImages/2] << endl;
    cout << "mean tracking time: " << totaltime/nImages << endl;

    // Save camera trajectory
    SLAM.SaveKeyFrameTrajectoryTUM( file_save_dir+"KeyFrameTrajectory.txt" );

    cout << "----end of program----" << endl << endl;
    return 0;
}

void LoadImages(const string &strFile, vector<string> &vstrImageFilenames, vector<double> &vTimestamps)
{
    ifstream f;
    f.open(strFile.c_str());

    // skip first three lines
    string s0;
    getline(f,s0);
    getline(f,s0);
    getline(f,s0);

    while(!f.eof())
    {
        string s;
        getline(f,s);
        if(!s.empty())
        {
            stringstream ss;
            ss << s;
            double t;
            string sRGB;
            ss >> t;
            vTimestamps.push_back(t);
            ss >> sRGB;
            vstrImageFilenames.push_back(sRGB);
        }
    }
}
