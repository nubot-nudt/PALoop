#!/bin/bash
./Monocular/mono_tum ../Vocabulary/ORBvoc.txt Monocular/TUM1.yaml /media/nubot22/QQ320G/\[data-sets\]/vision.in.tum.de_data_datasets/Handheld\ SLAM/rgbd_dataset_freiburg2_desk /home/nubot22/yqh_results/RGBDfreiburg2_desk_mono/
read
