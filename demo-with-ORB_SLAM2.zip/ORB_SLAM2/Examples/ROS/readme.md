###YQH
##编译
编译可能报错: undefined reference to symbol '_ZN5boost6system15system_categoryEv'
需要在CMakeLists.txt中添加
find_package( Boost REQUIRED COMPONENTS system)#yqh modified
...
set(LIBS 
boost_system#yqh modified
${OpenCV_LIBS} 
...

##运行
Running RGB_D Node

For an RGB-D input from topics /camera/rgb/image_raw and /camera/depth_registered/image_raw, run node ORB_SLAM2/RGBD. You will need to provide the vocabulary file and a settings file. See the RGB-D example above.

#example
注意：读取图像的的深度值 与 ROS topic 的深度值 单位是不一样的，具体要修改*.yaml中的DepthMapFactor参数
参考 roslaunch ORB_SLAM2 RGBD.launch

rosrun ORB_SLAM2 RGBD /home/nubot22/ORB_SLAM2/Vocabulary/ORBvoc.txt /home/nubot22/ORB_SLAM2/Examples/RGB-D/TUM3.yaml
rosbag play /home/nubot22/rgbd_dataset_freiburg3_long_office_household.bag /camera/rgb/image_color:=/camera/rgb/image_raw /camera/depth/image:=/camera/depth_registered/image_raw



相机在世界中的位姿 <==> Twc
