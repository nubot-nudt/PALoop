/**
* This file is part of ORB-SLAM2.
*
* Copyright (C) 2014-2016 Raúl Mur-Artal <raulmur at unizar dot es> (University of Zaragoza)
* For more information see <https://github.com/raulmur/ORB_SLAM2>
*
* ORB-SLAM2 is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* ORB-SLAM2 is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with ORB-SLAM2. If not, see <http://www.gnu.org/licenses/>.
*/


#include<iostream>
#include<algorithm>
#include<fstream>
#include<chrono>

#include<ros/ros.h>
#include <cv_bridge/cv_bridge.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>

#include<opencv2/core/core.hpp>

#include"../../../include/System.h"
#include <nav_msgs/Odometry.h> ///yqh
#include <tf2_ros/transform_broadcaster.h>///yqh
#include <boost/thread.hpp>///yqh
#include <boost/filesystem.hpp>///yqh

using namespace std;

class ImageGrabber
{
public:
    ImageGrabber(ORB_SLAM2::System* pSLAM):mpSLAM(pSLAM)
    {///yqh
        boost::thread t1(boost::bind(&ImageGrabber::odomAndPublish, this));
    }

    void GrabRGBD(const sensor_msgs::ImageConstPtr& msgRGB,const sensor_msgs::ImageConstPtr& msgD);
    struct FrameUnion///yqh
    {
        ORB_SLAM2::Frame frame;
        cv::Mat rgb;
        cv::Mat depth;
        ros::Time stamp;
        std::string frame_id;
    };
    std::list<FrameUnion> frame_buffer;///yqh
    void odomAndPublish();///yqh

    ORB_SLAM2::System* mpSLAM;
    ros::Publisher odomPub_;///yqh
    std::string odom_id;///yqh
    tf2_ros::TransformBroadcaster tfBroadcaster_odom;///yqh
    std::string file_save_dir;
    std::ofstream trajectory_file;///yqh
    std::ofstream covar_pose_file;///yqh
    std::ofstream covar_covis_file;///yqh
    double time_cost;///yqh
    ulong time_cost_den;///yqh
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "RGBD");
    ros::start();

    if(argc != 3)
    {
        cerr << endl << "Usage: rosrun ORB_SLAM2 RGBD path_to_vocabulary path_to_settings" << endl;        
        ros::shutdown();
        return 1;
    }    

    ros::NodeHandle nh;
    ros::NodeHandle pnh("~");///yqh
    std::string file_save_dir =  std::string(getenv( "HOME"))+"/yqh_results/";///yqh
    pnh.getParam( "file_save_dir", file_save_dir );///yqh
    if( !boost::filesystem::is_directory(file_save_dir) )
    {
        if(boost::filesystem::create_directory(file_save_dir))
            std::cout << "\033[43;31mcreat directory: " << file_save_dir << "\033[m" << std::endl;
        else
        {
            std::cout << "\033[43;31mFailed to creat directory: " << file_save_dir << "\033[m\007" << std::endl;
            return 1;
        }
    }
    else
        std::cout << "\033[43;31mFiles will be saved in directory: " << file_save_dir << "\033[m" << std::endl;

    // Create SLAM system. It initializes all system threads and gets ready to process frames.
    ORB_SLAM2::System SLAM(argv[1],argv[2],ORB_SLAM2::System::RGBD,true, file_save_dir+"yqh");//yqh? 不加点东西运行会报错
    SLAM.mpTracker->static_kf_interval = 30;
    boost::filesystem::create_directory(file_save_dir+"yqh"+"keyframes/");

    ImageGrabber igb(&SLAM);


    message_filters::Subscriber<sensor_msgs::Image> rgb_sub(nh, "/camera/rgb/image_raw", 1);
    message_filters::Subscriber<sensor_msgs::Image> depth_sub(nh, "camera/depth_registered/image_raw", 1);
    typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::Image> sync_pol;
    message_filters::Synchronizer<sync_pol> sync(sync_pol(10), rgb_sub,depth_sub);
    sync.registerCallback(boost::bind(&ImageGrabber::GrabRGBD,&igb,_1,_2));
    igb.odomPub_ = nh.advertise<nav_msgs::Odometry>("odom", 1);///yqh
    pnh.getParam( "odom_id", igb.odom_id );///yqh
    igb.file_save_dir = file_save_dir;
    igb.trajectory_file.open( (file_save_dir+"pose.txt").c_str());///yqh
    igb.trajectory_file << "#timestamp tx ty tz qx qy qz qw" << std::endl;///yqh
    igb.trajectory_file << std::fixed;
    igb.covar_pose_file.open((file_save_dir+"covar_pose.txt").c_str());///yqh
    igb.covar_pose_file << "#c11 c12 c13 c14 c15 c16 c22 c23 c24 c25 c26 c33 c34 c35 c36 c44 c45 c46 c55 c56 c66" << std::endl;///yqh 对称矩阵
    igb.covar_covis_file.open((file_save_dir+"covar_covis.txt").c_str());///yqh
    igb.covar_covis_file << "#c11 c12 c13 c14 c15 c16 c22 c23 c24 c25 c26 c33 c34 c35 c36 c44 c45 c46 c55 c56 c66" << std::endl;///yqh 对称矩阵

    ros::spin();

    // Stop all threads
    SLAM.Shutdown();

    // Save camera trajectory
    SLAM.SaveKeyFrameTrajectoryTUM("KeyFrameTrajectory.txt");
    igb.trajectory_file.close();///yqh
    igb.covar_pose_file.close();///yqh
    igb.covar_covis_file.close();///yqh
    if( igb.time_cost_den>0 )
        std::cout << "\n\033[33mtime per frame: " << igb.time_cost/igb.time_cost_den*1000 << " ms, fps= " << igb.time_cost_den/igb.time_cost << "\n\033[m" << std::endl;
    ros::shutdown();

    return 0;
}

void ImageGrabber::GrabRGBD(const sensor_msgs::ImageConstPtr& msgRGB,const sensor_msgs::ImageConstPtr& msgD)
{
//    static ros::Time time_static = ros::Time::now ();
//    static ros::Time time_static2 = msgRGB->header.stamp;
    if(frame_buffer.size()<2)///yqh: we buff only 2 frames;
    {
//        ros::Time time0 = ros::Time::now ();
        // Copy the ros image message to cv::Mat.
        cv_bridge::CvImageConstPtr cv_ptrRGB;
        try
        {
            cv_ptrRGB = cv_bridge::toCvShare(msgRGB,"bgr8");///yqh: add "bgr8"
        }
        catch (cv_bridge::Exception& e)
        {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }

        cv_bridge::CvImageConstPtr cv_ptrD;
        try
        {
            cv_ptrD = cv_bridge::toCvShare(msgD);
        }
        catch (cv_bridge::Exception& e)
        {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }
        ORB_SLAM2::Frame frame = mpSLAM->mpTracker->prepareFrame( cv_ptrRGB->image,cv_ptrD->image,cv_ptrRGB->header.stamp.toSec() );///yqh
        FrameUnion frameU;
        frameU.rgb = cv_ptrRGB->image.clone();
        frameU.depth=cv_ptrD->image.clone();
        frameU.stamp=cv_ptrRGB->header.stamp;
        frameU.frame_id=cv_ptrRGB->header.frame_id;
        frameU.frame=frame;
        frame_buffer.push_back( frameU );
//        ros::Time time1 = ros::Time::now ();
//        double time_cost = ( time1.toSec()-time0.toSec() )/1;
//        std::cout << "\t\t\t\t\t\t\t prepareFrame cost = " << time_cost*1000 << "ms" << std::endl;
    }
//    double time_cost = ( ros::Time::now ().toSec()-time_static.toSec() )/1;
//    std::cout << "\t\t\t\t\t\t\t frame recieve interval = " << time_cost*1000 << "ms" << std::endl;
//    time_static = ros::Time::now ();

//    time_cost = ( msgRGB->header.stamp.toSec()-time_static2.toSec() )/1;
//    std::cout << "\t\t\t\t\t\t\t frame pub interval = " << time_cost*1000 << "ms" << std::endl;
//    time_static2 = msgRGB->header.stamp;
    ///
}
void ImageGrabber::odomAndPublish()///yqh
{
    time_cost = 0;
    time_cost_den = 0;
    Eigen::Matrix3f Rotate_cam2groundtruth;//yqh Warning!!! x=z y=-x z=-y
    Rotate_cam2groundtruth << 0,0,1,  -1,0,0,  0,-1,0;
    while(1)
    if( frame_buffer.size()>0 )
    {
        ros::Time time0 = ros::Time::now ();
        FrameUnion frame_union = frame_buffer.front();
        Eigen::Matrix<double, 6, 6> covariance_pose;
        Eigen::Matrix<double, 6, 6> covariance_covis;
        cv::Mat Tcw_yqh = mpSLAM->TrackRGBD( frame_union.rgb,frame_union.depth,frame_union.stamp.toSec(), &frame_union.frame, &covariance_covis);
        covariance_pose = frame_union.frame.sigma2_pose_;
        Tcw_yqh = frame_union.frame.mTcw.clone();
//        std::cout << "\033[33m sigma2_covisible=" << mpLocalMapper->cnt_covisible << "\n" << mpLocalMapper->sigma2_covisible << "\033[m" << std::endl;
        frame_buffer.pop_front();

        if( !Tcw_yqh.empty() )
        {
            cv::Mat Twc_yqh = Tcw_yqh.inv();
            Eigen::MatrixXf Twc_eigen = Eigen::Map<Eigen::MatrixXf>( (float*)Twc_yqh.data, 4, 4 ).transpose();//eig矩阵默认按列存储 (4,4,CV_32F)
            Eigen::Vector3f position = Twc_eigen.topRightCorner<3,1>();
            position = Rotate_cam2groundtruth*position;
            Eigen::Matrix3f R_eigen = Rotate_cam2groundtruth*Twc_eigen.topLeftCorner<3,3>();
            Eigen::Quaternionf orientation( R_eigen );

            geometry_msgs::Transform odom_pos;
            odom_pos.translation.x = position(0);
            odom_pos.translation.y = position(1);
            odom_pos.translation.z = position(2);
            odom_pos.rotation.x = orientation.x();
            odom_pos.rotation.y = orientation.y();
            odom_pos.rotation.z = orientation.z();
            odom_pos.rotation.w = orientation.w();

            geometry_msgs::TransformStamped tf_odom;
            tf_odom.header.stamp = frame_union.stamp; // use corresponding time stamp to image
            tf_odom.header.frame_id = odom_id;
            tf_odom.child_frame_id = frame_union.frame_id;
            //    tf_odom.transform = odom_pos;
            tf_odom.transform.translation.x = 0;
            tf_odom.transform.translation.y = 0;
            tf_odom.transform.translation.z = 0;
            tf_odom.transform.rotation.x = 0;
            tf_odom.transform.rotation.y = 0;
            tf_odom.transform.rotation.z = 0;
            tf_odom.transform.rotation.w = 1;
            tfBroadcaster_odom.sendTransform(tf_odom);

            if(odomPub_.getNumSubscribers())
            {
                nav_msgs::Odometry odom;
                odom.header.stamp = tf_odom.header.stamp;
                odom.header.frame_id = tf_odom.header.frame_id;
                odom.child_frame_id = tf_odom.child_frame_id;
                odom.pose.pose.position.x = odom_pos.translation.x;
                odom.pose.pose.position.y = odom_pos.translation.y;
                odom.pose.pose.position.z = odom_pos.translation.z;
                odom.pose.pose.orientation = odom_pos.rotation;
                odomPub_.publish(odom);
            }

            trajectory_file << std::setprecision(4) << tf_odom.header.stamp.toSec() << " " << odom_pos.translation.x << " " << odom_pos.translation.y << " " << odom_pos.translation.z
                      << " " << odom_pos.rotation.x << " " << odom_pos.rotation.y << " " << odom_pos.rotation.z << " " << odom_pos.rotation.w << std::endl;

            Eigen::Matrix6d rotate6d;
            rotate6d.setZero();
            rotate6d.topLeftCorner<3,3>() = Rotate_cam2groundtruth.cast<double>();
            rotate6d.bottomRightCorner<3,3>() = Rotate_cam2groundtruth.cast<double>();
            covariance_pose  = rotate6d * covariance_pose  * rotate6d.transpose();
            covariance_covis = rotate6d * covariance_covis * rotate6d.transpose();
            covar_pose_file<<covariance_pose(0,0)<<" "<<covariance_pose(0,1)<<" "<<covariance_pose(0,2)<<" "<<covariance_pose(0,3)<<" "<<covariance_pose(0,4)<<" "<<covariance_pose(0,5)<<" "
                           <<covariance_pose(1,1)<<" "<<covariance_pose(1,2)<<" "<<covariance_pose(1,3)<<" "<<covariance_pose(1,4)<<" "<<covariance_pose(1,5)<<" "
                           <<covariance_pose(2,2)<<" "<<covariance_pose(2,3)<<" "<<covariance_pose(2,4)<<" "<<covariance_pose(2,5)<<" "
                           <<covariance_pose(3,3)<<" "<<covariance_pose(3,4)<<" "<<covariance_pose(3,5)<<" "
                           <<covariance_pose(4,4)<<" "<<covariance_pose(4,5)<<" "
                           <<covariance_pose(5,5)<<" "<< std::endl;
            covar_covis_file<<covariance_covis(0,0)<<" "<<covariance_covis(0,1)<<" "<<covariance_covis(0,2)<<" "<<covariance_covis(0,3)<<" "<<covariance_covis(0,4)<<" "<<covariance_covis(0,5)<<" "
                            <<covariance_covis(1,1)<<" "<<covariance_covis(1,2)<<" "<<covariance_covis(1,3)<<" "<<covariance_covis(1,4)<<" "<<covariance_covis(1,5)<<" "
                            <<covariance_covis(2,2)<<" "<<covariance_covis(2,3)<<" "<<covariance_covis(2,4)<<" "<<covariance_covis(2,5)<<" "
                            <<covariance_covis(3,3)<<" "<<covariance_covis(3,4)<<" "<<covariance_covis(3,5)<<" "
                            <<covariance_covis(4,4)<<" "<<covariance_covis(4,5)<<" "
                            <<covariance_covis(5,5)<<" "<< std::endl;
        }

        ros::Time time1 = ros::Time::now ();
        time_cost += time1.toSec()-time0.toSec();
        time_cost_den ++;
    }
    else
        usleep(3000);
}
