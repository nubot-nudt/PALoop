###YQH
TUM Dataset

    Download a sequence from http://vision.in.tum.de/data/datasets/rgbd-dataset/download and uncompress it.

    Associate RGB images and depth images using the python script associate.py. We already provide associations for some of the sequences in Examples/RGB-D/associations/. You can generate your own associations file executing:

python associate.py PATH_TO_SEQUENCE/rgb.txt PATH_TO_SEQUENCE/depth.txt > associations.txt

    Execute the following command. Change TUMX.yaml to TUM1.yaml,TUM2.yaml or TUM3.yaml for freiburg1, freiburg2 and freiburg3 sequences respectively. Change PATH_TO_SEQUENCE_FOLDERto the uncompressed sequence folder. Change ASSOCIATIONS_FILE to the path to the corresponding associations file.

./Examples/RGB-D/rgbd_tum Vocabulary/ORBvoc.txt Examples/RGB-D/TUMX.yaml PATH_TO_SEQUENCE_FOLDER ASSOCIATIONS_FILE

### Example:
./Examples/RGB-D/rgbd_tum Vocabulary/ORBvoc.txt Examples/RGB-D/TUM1.yaml /media/nubot22/QQ320G/\[data-sets\]/vision.in.tum.de_data_datasets/Handheld\ SLAM/rgbd_dataset_freiburg1_desk/ ./Examples/RGB-D/associations/fr1_desk.txt

./Examples/RGB-D/rgbd_tum Vocabulary/ORBvoc.txt Examples/RGB-D/TUM3.yaml /media/nubot22/QQ320G/\[data-sets\]/vision.in.tum.de_data_datasets/Handheld\ SLAM/rgbd_dataset_freiburg3_long_office_household/ ./Examples/RGB-D/associations/fr3_office.txt
