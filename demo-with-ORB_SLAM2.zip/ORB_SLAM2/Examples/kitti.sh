#!/bin/bash
./Stereo/stereo_kitti ../Vocabulary/ORBvoc.txt Stereo/KITTI00-02.yaml /media/nubot22/QQ320G/[data-sets]/kitti/odometry/sequences/00 /home/nubot22/yqh_results/kitti_00/
read
