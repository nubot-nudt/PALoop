如果你修改了ORB-SLAM的头文件，那么你要将ROS example也“完全”重编译才行。
因为有个编译的bug
ROS example用到了ORB-SLAM的头文件和库文件，但是普通重编译ROS example的话，只会重新链接库文件，而没有重新编译源文件，使得ROS example相当于还是以为按照旧的头文件去使用库文件，程序运行将出错。
